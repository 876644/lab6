package com.company.Commands;

public class clearCommand extends AbstractCommand {

    private static final long serialVersionUID = 1;

}