package com.company.Commands;

public class remove_headCommand extends AbstractCommand {
    private static final long serialVersionUID = 12;
}
