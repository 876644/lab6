package com.company.Enums;

public enum ColorEye {
    GREEN,
    YELLOW,
    ORANGE,
    WHITE;
}
