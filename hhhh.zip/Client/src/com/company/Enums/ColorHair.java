package com.company.Enums;

public enum ColorHair {
    GREEN,
    RED,
    YELLOW,
    WHITE;
}
