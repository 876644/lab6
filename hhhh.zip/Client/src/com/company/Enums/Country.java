package com.company.Enums;

public enum Country {
    RUSSIA,
    GERMANY,
    CHINA,
    NORTH_KOREA;
}
