package com.company.Enums;

public enum Semester {
    FIFTH,
    SIXTH,
    SEVENTH;
}
