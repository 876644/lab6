package com.company.Utility;

public interface Command {
    void execute();
}
